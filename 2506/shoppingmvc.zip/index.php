<?php
    require("system/load.php");
    require("system/MY_Controller.php");
    require("application/config/database.php");
    require("system/databaseClass.php");
    require("system/MY_Model.php");
    $objLoad = new load;
    
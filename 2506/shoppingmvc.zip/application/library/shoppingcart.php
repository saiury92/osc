<?php
class shoppingcart 
{
    public function __construct()
    {
        session_start();
    }
    public function insert($data = array(),$key)
    {
        if(!isset($_SESSION['cart']) || $_SESSION['cart'] == null) {
            $soluong = 1;
            $data['qty'] = $soluong;
            $_SESSION['cart'][$data[$key]] = $data;       
        }else{
            if(array_key_exists($data[$key],$_SESSION['cart']))
            {
                $soluong = $_SESSION['cart'][$data[$key]]['qty'] + 1;
                $data['qty'] = $soluong;
                $_SESSION['cart'][$data[$key]] = $data;
            }else{
                $soluong = 1;
                $data['qty'] = $soluong;
                $_SESSION['cart'][$data[$key]] = $data;
            }
        }
    }
    public function view()
    {
        $data = isset($_SESSION['cart']) && $_SESSION['cart'] != null ? $_SESSION['cart'] : array();
        return $data;
    }
    
    public function update($arrayNumber = array())
    {
        if(!isset($_SESSION['cart']) || $_SESSION['cart'] == null ) {
            return false;
        }
        foreach($arrayNumber as $key=>$val) {
            if(array_key_exists($key,$_SESSION['cart'])) {
                if($val <= 0){
                    unset($_SESSION['cart'][$key]);   
                }else{
                    $_SESSION['cart'][$key]['qty'] = $val;
                }
            }
        }
    }
    public function detete()
    {
        
    }
    public function total()
    {
        $total = 0;
        if(isset($_SESSION['cart']) && $_SESSION['cart'] != null ) {
            foreach($_SESSION['cart'] as $val) {
                $total += $val['qty'];
            }
        }
        return $total;
    }
}
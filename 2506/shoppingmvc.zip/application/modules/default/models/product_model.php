<?php
/**
 * Class name
 * Author:
 * Date
 */
 class product_model extends MY_Model
 {
    protected $_table = "product";
    public function listProduct()
    {
        return $this->getAll($this->_table);
    }
    public function getProductById($id)
    {
        $this->setWhere("pro_id = $id");
        return $this->getOnce($this->_table);
    }
 }
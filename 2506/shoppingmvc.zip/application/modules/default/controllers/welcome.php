<?php
/**
 * Class name
 * Author:
 * Date
 */
 class welcome extends MY_Controller
 {
    public function index()
    {
        echo "<h1>Hello My framework !</h1>";
    }
 }
<?php
/**
 * Class name
 * Author:
 * Date
 */
class product extends MY_Controller
 {
    public function listProduct()
    {
        $this->load->model("product_model");
        $data['listProduct'] = $this->model->listProduct();
        $this->load->library("shoppingcart");
        $data['totalCart'] = $this->library->total();
        $this->load->view("product/listproduct",$data);        
    }
 }
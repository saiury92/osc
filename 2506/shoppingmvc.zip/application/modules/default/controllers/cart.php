<?php
/**
 * Class Name
 * Author:
 * Date
 */
class cart extends MY_Controller
{
    public function insertCart()
    {
        $id = $_GET['id'];
        $this->load->model("product_model");
        $productInfo = $this->model->getProductById($id);
        $this->load->library("shoppingcart");
        $this->library->insert($productInfo,'pro_id');
        header("location:index.php?module=default&controller=product&action=listproduct");
    }
    public function viewCart()
    {
        $this->load->library("shoppingcart");
        $data['infoCart'] = $this->library->view();
        $this->load->view("cart/viewcart",$data);
    }
    public function updateCart()
    {
        if(isset($_POST['btnupdate'])) {
            $number = $_POST['number'];
            $this->load->library("shoppingcart");
            $data['infoCart'] = $this->library->update($number);
        }
        header("location:index.php?module=default&controller=cart&action=viewcart");
    }
}
<?php
class user extends MY_Controller
{
    public function listUser()
    {
        $this->load->model("user_model");
        $data['listUser'] = $this->model->listUser();
        $this->load->view("user/listuser",$data);   
    }
    public function insertuser()
    {
        $dataInsert = array(
                        "name"=>"Nguyen Van B",
                        "email"=>"bbb@gmail.com",
                        "address"=>"Ha Noi",
                        "phone"=>"8764756333"
                      );
        $this->load->model("user_model");
        $objUser = new user_model;
        $objUser->insertUser($dataInsert);
        $this->load->view("user/insertuser");
        header("location:index.php?module=admin&controller=user&action=listuser");
    }
    
    public function updateUser()
    {
        $id = 28;
        $dataUpdate = array(
                        "name"=>"Nguyen Van C",
                        "email"=>"ccc@gmail.com",
                        "address"=>"Ha Noi",
                        "phone"=>"123456789"
                      );
        $this->load->model("user_model");
        $objUser = new user_model;
        $objUser->updateUser($dataUpdate,$id);
        header("location:index.php?module=admin&controller=user&action=listuser");
    }
    public function deleteUser()
    {
        $id = $_GET['id'];
        $this->load->model("user_model");
        $objUser = new user_model;
        $objUser->deleteUser($id);
        header("location:index.php?module=admin&controller=user&action=listuser");
    }
}
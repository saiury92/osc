<?php
/**
 * Class name:
 * Author:
 * Date:
 */
 class database
 {
    const hostname  = 'localhost';
    const username  = 'root';
    const password  = '';
    const dbname  = 'phpsmartosc';
 }
<?php
mysql_connect('localhost','root','giang');
mysql_select_db('fresher04');
mysql_set_charset('utf8');
?>
<?php
	require_once("layout/top.php");
	$module = isset($_GET['module']) && $_GET['module'] != "" ? $_GET['module'] : "";
	switch($module) {
		case "user": require_once("modules/user/controller.php");break;
		case "category": require_once("modules/category/controller.php");break;
		case "product": require_once("modules/product/controller.php");break;
	}
	require_once("layout/footer.php");
        		
       

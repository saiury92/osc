﻿<h1>Danh sách thành viên</h1>
                <div id="control">
                        <a href="#">Delete Record</a>
                	<a href="index.php?module=user&action=insert">Insert</a>
                </div>
                <table width="700" border="1" cellpadding="0" cellspacing="0" id="list" style="clear:both;">
                	<tr>
                        <td class="header" align="center"><input type="checkbox" /></td>
                    	<td class="header">ID</td>
                    	<td class="header">Tên thành viên</td>
                    	<td class="header">Email</td>
                    	<td class="header">Phone</td>
                    	<td class="header">Address</td> 
                        <td class="header">Edit</td>
                        <td class="header">Delete</td>                                                                                            
                    </tr>
                    <tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td>Tên thành viên</td>
                    	<td>Email</td>
                    	<td>Phone</td>
                    	<td>Address</td>  
                        <td>Edit</td>
                    	<td>Delete</td>                                                                                                
                    </tr>
                    <tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td>Tên thành viên</td>
                    	<td>Email</td>
                    	<td>Phone</td>
                    	<td>Address</td>         
                        <td>Edit</td>
                    	<td>Delete</td>                                                                                       
                    </tr>
                    <tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td>Tên thành viên</td>
                    	<td>Email</td>
                    	<td>Phone</td>
                    	<td>Address</td>  
                        <td>Edit</td>
                    	<td>Delete</td>                                                                                              
                    </tr>
                    <tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td>Tên thành viên</td>
                    	<td>Email</td>
                    	<td>Phone</td>
                    	<td>Address</td>
                        <td>Edit</td>
                    	<td>Delete</td>                                                                                                
                    </tr>
                    <tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td>Tên thành viên</td>
                    	<td>Email</td>
                    	<td>Phone</td>
                    	<td>Address</td> 
                        <td>Edit</td>
                    	<td>Delete</td>                                                                                               
                    </tr><tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td>Tên thành viên</td>
                    	<td>Email</td>
                    	<td>Phone</td>
                    	<td>Address</td>
                        <td>Edit</td>
                    	<td>Delete</td>                                                                                                
                    </tr><tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td>Tên thành viên</td>
                    	<td>Email</td>
                    	<td>Phone</td>
                    	<td>Address</td>
                        <td>Edit</td>
                    	<td>Delete</td>                                                                                                
                    </tr>
                    <tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td>Tên thành viên</td>
                    	<td>Email</td>
                    	<td>Phone</td>
                    	<td>Address</td>  
                        <td>Edit</td>
                    	<td>Delete</td>                                                                                              
                    </tr>
                    <tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td>Tên thành viên</td>
                    	<td>Email</td>
                    	<td>Phone</td>
                    	<td>Address</td> 
                        <td>Edit</td>
                    	<td>Delete</td>                                                                                               
                    </tr>
                </table>
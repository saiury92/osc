﻿<h1>Thêm mới thành viên</h1>
                <form action="" method="post">
                	<label>Username</label>
                   	<input type="text" name="" value="" size="30" />
                    <br />
                	<label>Username</label>
                    <input type="text" name="" value="" size="30" />
                    <br />
                	<label>Username</label>
                    <input type="text" name="" value="" size="30" />
                    <br />
                	<label>Username</label>
                    <input type="text" name="" value="" size="30" />
                    <br /> 
                    <label>Vatata</label>
                    <input type="file" name="" value="" size="30" />
                    <br />     
                    <label>&nbsp;</label> 
                    <input type="submit" value="Insert" />
                    <input type="reset" value="Insert" />                                  
                </form>
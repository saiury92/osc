<?php
    if(isset($_POST['id'])) {
        switch($_POST['id']) {
            case 1: echo "<font color='red'>Gia tri vua gui len thuoc link </font>".$_POST['id']; break;
            case 2: echo "Gia tri vua gui len thuoc link ".$_POST['id']; break;
            case 3: echo "Gia tri vua gui len thuoc link ".$_POST['id']; break;
            case 4  : echo "Gia tri vua gui len thuoc link ".$_POST['id']; break;
        }
    }
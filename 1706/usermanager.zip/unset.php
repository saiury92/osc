<?php
$student = array();
$student[]= "htkhoi1";
$student[]= "htkhoi2";
$student[]= "htkhoi3";
$student[]= "htkhoi4";

echo "<pre>";
print_r($student);
echo "</pre>";
unset($student[2]);
echo "<pre>";
print_r($student);
echo "</pre>";


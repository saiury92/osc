<?php
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $file = file("user.txt");
        foreach($file as $key=>$val){
            $idUser = substr($val,0,strpos($val,'|'));
            if($idUser == $id){
                unset($file[$key]);
            }
        }
        file_put_contents("user.txt",$file);
        header("location:index.php");
    }
<?php
    session_start();
?>
<!DOCTYPE HTML>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="htkhoi" />
    <meta charset="utf-8" />
	<title>Đăng nhập hệ thống</title>
    <style>
        body{
            width:500px;
            margin: 100px auto;
        }
        h1{
            color:blue;
            font-size:14px;
            text-transform: uppercase;
            padding-left: 80px;
        }
        label{
            float:left;
            width:80px;
        }
        p{
            padding-left: 85px;
            color: red;
        }
        input{
            margin-bottom: 5px;
        }
        
    </style>
</head>
<body>
    <h1>Truy Cập Trang Quản trị</h1>
    <?php
        function debug($input){
            echo "<pre>";
            print_r($input);
            echo "</pre>";
        }
        /*
        if(isset($_POST['ok'])){
            if($_POST['username'] == NULL){
                echo "<p>Vui lòng nhập họ tên đầy đủ<p>";
            }else{
                $username = $_POST['username'];
            }
            if($_POST['password'] == NULL){
                echo "<p>Password không được bỏ trống</p>";
            }else{
                $password = $_POST['password'];
            }
            if(isset($username) && $username != NULL && isset($password) && $password != NULL){
                $file  = file("user.txt");
                
                foreach($file as $userInfo){
                     $infoUser[] = explode('|',$userInfo);
                }
                foreach($infoUser as $info){
                    if(trim($info[1]) == trim($username) && trim($info[4]) == trim($password)){
                        $_SESSION['username'] = $info[1];
                        $_SESSION['level']    =   $info[3];                  
                        header("location:index.php");
                        exit();
                    }else{
                        $erro[] = "<p>Sai tên đăng nhập hoặc mật khẩu</p>";      
                    }
                }
                if(count($erro) > 0){
                    echo $erro[0];
                }
            }
        }
        */  $username = $password = "";
            if(isset($_POST['ok'])){
                if(!isset($_POST['username']) || $_POST['username'] == NULL){
                    echo "<p>Vui lòng nhập họ tên đầy đủ<p>";
                }else{
                    $username = $_POST['username'];
                }
                if(!isset($_POST['password']) || $_POST['password'] == NULL){
                    echo "<p>Mật khẩu không được bỏ trống<p>";
                }else{
                    $password = $_POST['password'];
                }
                if(isset($username) && $username != NULL && isset($password) && $password != NULL){
                    $file = file("user.txt");
                    foreach($file as $listFile){
                        $infoUser[] = explode("|",$listFile);
                    }          
                    foreach($infoUser as $key=>$userValue){
                        //echo $userValue[1]."==>".strlen(trim($userValue[1]))."<br/>";
                        //echo $userValue[4]."==>".strlen(trim($userValue[4]))."<br/>";
                        if(trim($userValue[1]) == trim($username) && trim($userValue[4]) == trim($password)){
                            $_SESSION['username'] = $userValue[1];
                            $_SESSION['level'] = $userValue[3];
                            header("location:index.php");
                        }else{
                            $erro[] = "<p>Tên đang nhập hoặc mật khẩu không chính xác</p>";
                        }
                    }
                    if(count($erro) > 0){
                        echo $erro[0];
                    }
                }          
            }
?>
    <form action="login.php" method="post">
        <label>Username</label><input type="text" name="username" size="25" value="" /><br />
        <label>Password</label><input type="text" name="password" size="25" value="" /><br />
        <label>&nbsp;</label>
        <input type="submit" name="ok" value="Đăng nhập" />
    </form>
</body>
</html>
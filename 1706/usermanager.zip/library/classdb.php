<?php
require("config.php");
class database{
    protected $conn;
    protected $result;
    protected $hostname;
	protected $userhost;
	protected $passhost;
	protected $dbname;
    
    public function __construct(){
        $this->hostname = config::hostname;
        $this->userhost = config::userhost;
        $this->passhost = config::passhost;
        $this->dbname = config::dbname;
    }
    public function connect(){
        $this->conn = mysql_connect($this->hostname,$this->userhost,$this->passhost);
        mysql_select_db(config::dbname,$this->connect);
    }
    public function query($sql){
        if(!$this->conn){
            die("Khong ket noi duoc database");
        }else{
            return $this->result = mysql_query($sql);
        }
    }
    public function num_row(){
        if(!$this->result){
            die("Khong the query");
        }else{
            return mysql_num_rows($this->result);
        }
    }
    public function fetchAll(){    
        if(!$this->result){
            die("Khong the query");
        }else{
            return mysql_fetch_assoc($this->result);  
        }
    }
}
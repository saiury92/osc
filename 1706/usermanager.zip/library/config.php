<?php
class config{
    CONST hostname  = "localhost";
    CONST userhost  = "root";
    CONST passhost  = "";
    CONST dbname    = "user";
    
}
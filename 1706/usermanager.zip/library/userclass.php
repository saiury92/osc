<?php
require("classdb.php");
class userclass extends  database{
    protected $username;
    protected $password;
    protected $level;
    public function __construct(){
        parent::__construct();
        $this->connect();
    }
    public function setUsername($value){
        $this->username = $value;
    }
    public function getUsername(){
        return $this->username;
    }
    public function setPassword($value){
        $this->password = $value;
    }
    public function getPassword(){
        return $this->password;
    }
    public function setLevel($value){
        $this->level = $value;
    }
    public function getLevel(){
        return $this->level;
    }
    public function check_login(){
        $sql ="select * from user where username='".$this->getUsername()."' and password ='".$this->getPassword()."'";
        $this->query($sql);
        if($this->num_rows() == 0){
            return FALSE;
        }else{
            return $this->fetchAll();   
        }
    }
    public function listUser(){
        $sql = "select * from user";
        $this->query($sql);
        while($row = $this->fetchAll()){
            $data[] = $row;
        }
        return $data;
    }
}


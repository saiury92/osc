<?php
    session_start();
    if(!isset($_SESSION['username']) && !isset($_SESSION['level']) && $_SESSION['level'] != 2 ){
        header("location:login.php");
        exit();
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Thêm Thành Viên</title>
<style>
	form{
		width:500px;
		margin:0px auto;
	}
	label{
		width:120px;
		float:left;
	}
	input,select{
		margin-bottom:5px;	
	}
    body{
        width: 500px;
        margin: 100px auto;
    }
    a{
        text-decoration: none;
        color: blue;
    }
    font{
        padding-left: 120px;
    }
</style>
</head>
<body>
        <div>
        <a href="">Chào bạn: <?php echo $_SESSION['username']; ?></a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="logout.php">Đăng xuất</a>
        </div>
        <h3>
            Sửa thành viên
        </h3>
		<?php
            $file = file("user.txt");
            foreach($file as $listInfo){
                $idArr = substr($listInfo,0,strpos($listInfo,'|'));
                if($idArr == $_GET['id']){
                    $info = $listInfo;
                    break;
                }
            }
            $data_update = array();
            $data_update = explode('|',$info);    
            
            if(isset($_POST['ok'])){
                if(!isset($_POST['level']) || $_POST['level'] == 0){
                    echo "<font color='red'>Vui lòng chọn quyền hạn</font><br/>";
                }else{
                    $level = $_POST['level'];
                }
                if(!isset($_POST['username']) || $_POST['username'] == NULL){
                    echo "<font color='red'>Vui lòng nhập đầy đủ họ tên</font><br/>";
                }else{
                    $username = $_POST['username'];
                }
                if(isset($_POST['password']) && $_POST['password'] != NULL){
                    if($_POST['password'] != $_POST['repassword']){
                        echo "<font color='red'>Mật khẩu không trùng nhau</font><br/>";
                    }else{
                        $password = $_POST['password'];
                    }
                }else{
                    $file = file("user.txt");
                    foreach($file as $key=>$listInfo){
                        $infoOnce = explode('|',$listInfo);
                        $idArr = substr($listInfo,0,strpos($listInfo,'|'));
                        if($idArr == $_GET['id']){
                                $password = $infoOnce[4];    
                        }
                    }
                }
                
                if(!isset($_POST['email']) || $_POST['email'] == NULL){
                    echo "<font color='red'>Vui lòng nhập email của bạn</font><br/>";
                }else{
                    $email = $_POST['email'];
                }
                
                if(isset($level,$username,$email,$password)){
                    $file = file("user.txt");
                    foreach($file as $key=>$listInfo){
                         
                        $infoOnce = explode('|',$listInfo);
                        $idArr = substr($listInfo,0,strpos($listInfo,'|'));
                        if($idArr == $_GET['id']){
                                $info = $idArr."|".$username."|".$email."|".$level."|".$password;
                                $file[$key] = $info;    
                                break;
                        }
                    }
                    file_put_contents('user.txt',$file);
                    header("location:index.php");
                }
            }
        ?>
		<form action="update.php?id=<?php echo $data_update[0]; ?>" method="post" name="" enctype="multipart/form-data">
        	<label>Quyền hạn</label>
            		<select name="level">
                    	<option value="0">Chọn quyền hạn</option>
                    	<option value="2" <?php if($data_update[3] == 2){  ?> selected="selected" <?php } ?> >Administrator</option>
                        <option value="1" <?php if($data_update[3] == 1){  ?> selected="selected" <?php } ?> >Member</option>
                    </select><br />
        	<label>Tên thành viên</label><input type="text" name="username" value="<?php echo $data_update[1] ?>" size="40" /><br />
            <label>Mật khẩu</label><input type="text" name="password" value="" size="40" /><br />
            <label>Mật khẩu nhập lại</label><input type="text" name="repassword" value="" size="40" /><br />
        	<label>Địa Chỉ Email</label><input type="text" name="email" value="<?php echo $data_update[2] ?>" size="40" /><br />                        
            <label>&nbsp;</label>
            <input type="submit" name="ok" value="Sửa" />&nbsp;&nbsp;
            <input type="submit" name="ok" value="Làm lại" />
        </form>
</body>
</html>

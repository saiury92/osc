<?php
    session_start();
    if(!isset($_SESSION['username']) || !isset($_SESSION['level'])){
        header("location:login.php");
        exit();
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Danh sách thành viên</title>
<style>
    a{
        text-decoration: none;
        color: blue;
    }
	thead td{
		background:#f1f1f1;
		text-align:center;
		padding:0px; margin:0px;
		border:1px solid #fbfbfb;
	}
	tbody td{
		background:#fbfbfb;	
		border:1px solid;
		border:1px solid #f1f1f1;
	}
    body{
        width: 650px;
        margin: 100px auto;
    }
</style>
<script type="text/javascript">
    function xacnhan(){
        if(!window.confirm("Bạn có thực sự muốn xóa không ?")){
    		return false;
    	}
    }
</script>
</head>
<body>
<?php
    $file = file("user.txt");
    foreach($file as $listInfo){
        $user[] = explode('|',$listInfo); 
    }
?>
	<div>
        <a href="">Chào bạn: <?php echo $_SESSION['username']; ?></a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="logout.php">Đăng xuất</a>
    </div>
    <h3>
        Danh sách thành viên
    </h3>
	<table width="650" align="center" cellpadding="0" cellspacing="0">
    	<thead>
        	<tr>
                <td width="10%">Mã TV</td>
                <td width="30%">Họ Tên</td>
                <td width="30%">Email</td>
                <td width="15%">Quyền Hạn</td>
                <td width="10%">Sửa</td>
                <td width="10%">Xóa</td>
            </tr>
        </thead>
        <tbody>
            <?php
                if(isset($user) && $user != NULL){
                foreach($user as $listUser){
            ?>
        	<tr>
            	<td align="center"><?php echo $listUser[0] ?></td>
                <td align="center"><?php echo $listUser[1] ?></td>
                <td align="center"><?php echo $listUser[2] ?></td>
                <td align="center"><?php if($listUser[3] == 2){ echo "<font color='red'>Administrator</font>"; }else{ echo "Member"; } ?></td>
                <td align="center"><a href="update.php?id=<?php echo $listUser[0]; ?>" <?php if($_SESSION['level'] != 2){ ?> style="color: #ccc;" onclick="alert('Bạn không có quyền sử dụng chức năng này'); return false;" <?php } ?> >Sửa</a></td>
                <td align="center"><a href="delete.php?id=<?php echo $listUser[0]; ?>" <?php if($_SESSION['level'] != 2){ ?> style="color: #ccc;" onclick="alert('Bạn không có quyền sử dụng chức năng này'); return false;" <?php }else{ ?> onclick="return xacnhan();" <?php } ?> >Xóa</a></td>
            </tr>
            <?php }} ?>
            <tr>
                <td colspan="7" align='left'><a href="insert.php" <?php if($_SESSION['level'] != 2){ ?>  style="color: #ccc;" onclick="alert('Bạn không có quyền sử dụng chức năng này'); return false;"  <?php } ?>>Thêm mới</a></td>
            </tr>    
        </tbody>
        </thead>
    </table>
</body>
</html>

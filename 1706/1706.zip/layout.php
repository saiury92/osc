<link rel="stylesheet" href="style.css"/>
<div id="header">
    <div class="menu">
        <a href="themsv.php">Them sv</a>
        <a href="getSV.php">Danh Sach sv</a>
    </div>
</div>
<?php
    session_start();
    $product[1] = array(
                          "name"=>"Sony experia Z1",
                          "price"=>15000,
                          "bran"=>"Sony"
                      );
        $product[2] = array(
                          "name"=>"Sony experia Z2",
                          "price"=>16000,
                          "bran"=>"Sony"
                      );
        $product[3] = array(
                          "name"=>"Sony experia Z3",
                          "price"=>15000,
                          "bran"=>"Sony"
                      );
        $product[4] = array(
                          "name"=>"Sony experia Z4",
                          "price"=>16000,
                          "bran"=>"Sony"
                      );
        $product[5] = array(
                          "name"=>"Sony experia Z5",
                          "price"=>17000,
                          "bran"=>"Sony"
                      );
        $product[6] = array(
                          "name"=>"Sony experia Z6",
                          "price"=>18000,
                          "bran"=>"Sony"
                      );
        $product[7] = array(
                          "name"=>"Sony experia Z7",
                          "price"=>19000,
                          "bran"=>"Sony"
                      );
        $product[8] = array(
                          "name"=>"Sony experia Z8",
                          "price"=>20000,
                          "bran"=>"Sony"
                      );
        $product[9] = array(
                          "name"=>"Sony experia Z9",
                          "price"=>21000,
                          "bran"=>"Sony"
                      );
        $product[10] = array(
                          "name"=>"Sony experia Z10",
                          "price"=>21000,
                          "bran"=>"Sony"
                      );
        
       $id = $_GET['id'];
       if(!isset($_SESSION['cart']) || $_SESSION['cart'] == null ) {
            $soluong = 1;
            $product[$id]['soluong'] = $soluong;
            $_SESSION['cart'][$id] = $product[$id];
       }else{
            if(array_key_exists($id,$_SESSION['cart'])) {
                $soluong = $_SESSION['cart'][$id]['soluong'] + 1;
                $_SESSION['cart'][$id]['soluong'] = $soluong;
                
            }else{
               $soluong = 1;
               $product[$id]['soluong'] = $soluong;
               $_SESSION['cart'][$id] = $product[$id];
            }
       }
       header("location:shopping.php");
       exit();
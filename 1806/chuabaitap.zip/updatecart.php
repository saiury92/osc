<?php
session_start();
if(isset($_POST['btnok'])) {
       $numberArr = $_POST['number'];
       foreach($numberArr as $key=>$val) {
            if(array_key_exists($key,$_SESSION['cart'])) {
                if($val <= 0) {
                    unset($_SESSION['cart'][$key]);
                }else{
                    $_SESSION['cart'][$key]['soluong'] = $val;   
                }
            }
       }
       header("location:viewcart.php");
}
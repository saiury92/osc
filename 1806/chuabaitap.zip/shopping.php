<?php
    session_start();
?>
<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="KHOIPC" />
    <meta charset="utf-8" />
	<title>Untitled 1</title>
    <style>
        #wrapper{
            margin: 0px auto;
            width: 400px;
            border:1px solid #CCC;
            min-height: 1150px;
            padding: 5px
        }
        ul{
            margin: 0px;
            padding: 0px;
            list-style: none;
        }
        ul li{
            float: left;
            clear: left;
            border-bottom: 1px dashed #ccc;
            width: 100%;
        }
        ul li h1{
            font-size:14px;
            color: darkblue;
        }
        a{
            text-decoration: none;
            color: orange;
        }
        li.view{
            background: #f1f1f1;
            border: 1px dashed #ccc;
            padding: 5px;
            width: 390px;
        }
    </style>
</head>
<body>
    <?php
        $product = array();
        $product[1] = array(
                          "name"=>"Sony experia Z1",
                          "price"=>15000,
                          "bran"=>"Sony"
                      );
        $product[2] = array(
                          "name"=>"Sony experia Z2",
                          "price"=>16000,
                          "bran"=>"Sony"
                      );
        $product[3] = array(
                          "name"=>"Sony experia Z3",
                          "price"=>15000,
                          "bran"=>"Sony"
                      );
        $product[4] = array(
                          "name"=>"Sony experia Z4",
                          "price"=>16000,
                          "bran"=>"Sony"
                      );
        $product[5] = array(
                          "name"=>"Sony experia Z5",
                          "price"=>17000,
                          "bran"=>"Sony"
                      );
        $product[6] = array(
                          "name"=>"Sony experia Z6",
                          "price"=>18000,
                          "bran"=>"Sony"
                      );
        $product[7] = array(
                          "name"=>"Sony experia Z7",
                          "price"=>19000,
                          "bran"=>"Sony"
                      );
        $product[8] = array(
                          "name"=>"Sony experia Z8",
                          "price"=>20000,
                          "bran"=>"Sony"
                      );
        $product[9] = array(
                          "name"=>"Sony experia Z9",
                          "price"=>21000,
                          "bran"=>"Sony"
                      );
        $product[10] = array(
                          "name"=>"Sony experia Z10",
                          "price"=>21000,
                          "bran"=>"Sony"
                      );
    ?>
    <div id="wrapper">
    <ul>
        <li class="view">
            <p align='center'>Sản phẩm trong giỏ là: 
                <?php
                    $total = 0;
                   if(isset($_SESSION['cart']) && $_SESSION['cart'] != null ) {
                        foreach($_SESSION['cart'] as $list) {
                            $total += $list['soluong']; 
                        }
                   } 
                   echo "<a href='viewcart.php'>". $total ."</a>";
                ?>
            </p>
        </li>
        <?php
            foreach($product as $key=>$value) {
        ?>
        <li>
            <h1><?php echo $value['name']; ?></h1>
            <p>Giá:<?php echo $value['price']; ?></p>
            <p><a href="insertcart.php?id=<?php echo $key; ?>">Mua ngay</a></p>
        </li>
        <?php } ?>
    </ul>
    </div>
</body>
</html>
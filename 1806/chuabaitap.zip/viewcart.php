<meta charset="utf-8" />
<?php
session_start();
if(isset($_SESSION['cart']) && $_SESSION['cart'] != null ) {
    echo "<form action='updatecart.php' method='post'>";
    echo "<table border='1' cellpadding='0' cellspacing='0' width='500'>";
    echo "<tr>";
    echo "<td>Tên sản phẩm</td>";
    echo "<td>Giá</td>";
    echo "<td>Số lượng</td>";
    echo "<td>Thành tiền</td>";
    echo "<td>Xóa</td>";
    echo "</tr>";
    foreach($_SESSION['cart'] as $key=>$listProduct) {
        echo "<tr>";
        echo "<td>".$listProduct['name']."</td>";
        echo "<td>".$listProduct['price']."</td>";
        echo "<td><input type='number' name='number[".$key."]' value='".$listProduct['soluong']."' /></td>";
        echo "<td>".($listProduct['price']*$listProduct['soluong'])."</td>";
        echo "<td><a href='deletecart.php?id=".$key."'>Xóa</a></td>";
        echo "</tr>";
    }
    echo "<tr>";
    echo "<td colspan='5' align='right'><input type='submit' name='btnok' value='Cập nhật'/></td>";
    echo "</tr>";
    echo "</table>";
    echo "</form>";
}else{
    echo "<h3>Chưa có sản phẩm trong giỏ</h3>";
}
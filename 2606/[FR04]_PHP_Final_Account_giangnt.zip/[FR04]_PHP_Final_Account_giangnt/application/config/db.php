<?php
/**
 * Class name:
 * Author:
 * Date:
 */
 class db
 {
    const hostname  = 'localhost';
    const username  = 'root';
    const password  = 'giang';
    const dbname  = 'phpsmartosc';
 }
<?php
define("APPLICATION_PATH","application");
define("ADMIN_CSS","public/admin/css");
define("ADMIN_IMAGES","public/admin/images");
define("ADMIN_JS","public/admin/js");

define("FRONTEND_CSS","public/frontend/css");
define("FRONTEND_IMAGES","public/frontend/images");
define("FRONTEND_JS","public/frontend/js");

define('BASE_URL',  dirname($_SERVER['PHP_SELF']));

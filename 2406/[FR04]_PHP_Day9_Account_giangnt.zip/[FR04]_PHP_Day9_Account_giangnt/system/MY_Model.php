<?php
/**
 * Class name
 * Author:
 * Date:
 */
class MY_Model extends Database
{
    public function __construct()
    {
        parent::__construct();
    }
}
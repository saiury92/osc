<?php
/**
 * Class name:
 * Author:
 * Date:
 */
 class db
 {
    const hostname  = 'localhost';
    const username  = 'root';
    const password  = '';
    const dbname  = 'fresher04';
 }
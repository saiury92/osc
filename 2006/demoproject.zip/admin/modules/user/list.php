﻿<h1>Danh sách thành viên</h1>
                <div id="control">
                        <a href="#">Delete Record</a>
                	<a href="index.php?module=user&action=insert">Insert</a>
                </div>
                <table width="700" border="1" cellpadding="0" cellspacing="0" id="list" style="clear:both;">
                    <tr>
                        <td class="header" align="center"><input type="checkbox" /></td>
                    	<td class="header">ID</td>
                    	<td class="header">Tên thành viên</td>
                    	<td class="header">Email</td>
                    	<td class="header">Phone</td>
                    	<td class="header">Address</td> 
                        <td class="header">Edit</td>
                        <td class="header">Delete</td>                                                                                            
                    </tr>
		    <?php
			$sql = "SELECT * FROM tbl_user";
			$objUser = new user;
			$dataUser = $objUser->listUser($sql);
			foreach($dataUser as $listUser) {
		    ?>
                    <tr>
                        <td align="center"><input type="checkbox" /></td>
                    	<td>ID</td>
                    	<td><?php echo $listUser['name']; ?></td>
                    	<td><?php echo $listUser['email']; ?></td>
                    	<td><?php echo $listUser['phone']; ?></td>
                    	<td><?php echo $listUser['address']; ?></td>  
                        <td><a href='index.php?module=user&action=edit&id=<?php echo $listUser['id']; ?>'>Edit</td>
			<td><a href='index.php?module=user&action=delete&id=<?php echo $listUser['id']; ?>'>Delete</td>
                    </tr>
			<?php } ?>
                </table>
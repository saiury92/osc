﻿		<?php
			$name = isset($_POST['name']) && $_POST['name'] != "" ? $_POST['name'] : "";
			$email = isset($_POST['email']) && $_POST['email'] != "" ? $_POST['email'] : "";
			$address = isset($_POST['address']) && $_POST['address'] != "" ? $_POST['address'] : "";
			$phone = isset($_POST['phone']) && $_POST['phone'] != "" ? $_POST['phone'] : "";
			if($name && $email && $address && $phone) {
				$obj = new user;
				$obj->setName($name);
				$obj->setEmail($email);
				$obj->setAddress($address);
				$obj->setPhone($phone);
				$obj->insertUser();
				header("location:index.php?module=user");
			}
		?>
		<h1>Thêm mới thành viên</h1>
                <form action="" method="post">
                	<label>Username</label>
                   	<input type="text" name="name" value="" size="30" />
			<span color='red'><?php echo !$name ? "Vui long nhap ten" :"";  ?></span>
                    <br />
                    <label>Email</label>
                    <input type="text" name="email" value="" size="30" />
		    <span color='red'><?php echo !$email ? "Vui long nhap email" :"";  ?></span>
                    <br />
                    <label>Address</label>
                    <input type="text" name="address" value="" size="30" />
		    <span color='red'><?php echo !$address ? "Vui long nhap address" :"";  ?></span>	
                    <br />
                    <label>Phone</label>
                    <input type="text" name="phone" value="" size="30" />
		    <span color='red'><?php echo !$phone ? "Vui long nhap phone" :"";  ?></span>	
                    <br />    
                    <label>&nbsp;</label> 
                    <input type="submit" value="Insert" />
                    <input type="reset" value="Reset" />                                  
                </form>
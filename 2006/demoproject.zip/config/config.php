<?php
class config
{
	const hostname = "localhost";
	const username = "root";
	const password= "";
	const dbname = "phpsmartosc";
}
function debug($data = array()) {
	echo "<pre>";
	print_r($data);
	echo "</pre>";
}
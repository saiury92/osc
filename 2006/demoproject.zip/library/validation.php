<?php
final class validation
{

	static function isNull($name) {
		$flag = true;
		if(!isset($_POST[$name]) || $_POST[$name] == "") {
			$flag = false;
		}
		return $flag;
	}
}
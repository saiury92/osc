<?php
    require_once("application/modules/admin/views/layout/header.php");
    require_once("application/modules/admin/views/".$template.".php");
    require_once("application/modules/admin/views/layout/footer.php");
?>
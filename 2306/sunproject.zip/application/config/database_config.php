<?php
/**
 * Class name: database-config
 * Author: ChungND
 */
 class database_config
 {
    const HOSTNAME = "localhost";   
    const USERNAME = "root";
    const PASSWORD = "";
    const DBNAME  = "mockproject";
 }
<?php
define("APPLICATION_PATH","application/");
define("ADMIN_CSS","public/admin/css/");
define("ADMIN_IMAGES","public/admin/images/");
define("ADMIN_JS","public/admin/js");
<?php
/**
 * Class name: my_model
 * Author:
 * Date:
 * lớp cơ sở của model, tất cả các lớp model phải kế thừa
 */
class MY_Model extends Database
{
    public function __construct()
    {
        parent::__construct();
    }
}
<?php
/**
 * Class name: db
 * Author:
 * Date:
 * Config database
 */
 class db
 {
    const hostname  = 'localhost';
    const username  = 'root';
    const password  = 'giang';
    const dbname  = 'fresher04';
 }